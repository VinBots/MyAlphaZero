match :: (Integral i) => x -> String
match 42 = "The Answer"
match 41 = "Close but not quite"
match x = "I can't match that!"