let m i =
    match i with
    | 42 -> "The Answer"
    | 41 -> "Close but not quite"
    | _  -> "I can't match that!"
