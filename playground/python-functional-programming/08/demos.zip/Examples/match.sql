select
    case i
        when 42 then 
            "The Answer"
        when 41 then 
            "Close but not quite"
        else         
            "I can't match that!"
    end
