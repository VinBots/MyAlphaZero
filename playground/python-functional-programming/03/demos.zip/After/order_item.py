class OrderItem:
    name = ''
    itemnumber = ''
    quantity = 0
    price = 0
    backorderd = False
