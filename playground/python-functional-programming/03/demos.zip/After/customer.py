class Customer:
    name = ''
    address = ''
    enterprise = False
